/* standard.c				Wed Oct 25 23:35:33 1995
 *
 * This program produced by gofc 1.02 (2.30a) from:
 *	standard.prelude
 */

